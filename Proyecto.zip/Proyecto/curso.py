class Curso:
    def __init__(self, id, nombre, horas_semana, restricciones):
        self.id = id
        self.nombre = nombre
        self.horas_semana = horas_semana
        self.restricciones = restricciones