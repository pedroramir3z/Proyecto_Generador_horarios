import tkinter as tk 
from tkinter import ttk, messagebox
from tkinter.font import BOLD
import util.generic as utl
from tkinter import *
from tkinter import ttk

def genera():
    
    def crear_tabla(matriz):
        root = tk.Tk()
        root.title("GENERAR HORARIO")
        w, h = root.winfo_screenwidth(), root.winfo_screenheight()                                    
        root.geometry("%dx%d+0+0" % (w, h))
        root.config(bg='black')
        root.resizable(width=0, height=0)  

        num_filas = len(matriz)
        num_columnas = len(matriz[0])

        # Crear el marco para la tabla
        frame = tk.Frame(root)
        frame.pack()

        # Crear etiquetas para las columnas
        for j in range(num_columnas):
            label = tk.Label(frame, text=f"Columna {j+1}", relief=tk.RIDGE, width=30)
            label.grid(row=0, column=j)

        # Agregar datos a la tabla
        for i in range(num_filas):
            for j in range(num_columnas):
                label = tk.Label(frame, text=str(matriz[i][j]), relief=tk.RIDGE, width=30)
                label.grid(row=i+1, column=j)

        root.mainloop()

    # Ejemplo de matriz
    mi_matriz = [('FUNDAMENTOS DE LA PROGRAMACION', 'Claudia Sánchez Rodríguez', 101, 'MARTESxJUEVES-11AM-A-12:55PM'), ('ETICA Y LEGISLACION', 'Alberto Castro Martínez', 101, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('LOGICA MATEMATICA', 'Beatriz Hernández Pérez', 101, 'LUNESxMIERCOLES-3PM-A-4:55PM'), ('PRECALCULO', 'Beatriz Hernández Pérez', 102, 'MARTESxJUEVES-3PM-A-4:55PM'), ('INTRODUCCION A LA INGENIERIA', 'Alberto Castro Martínez', 101, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('PROGRAMACION ESTRUCTURADA', 'Claudia Sánchez Rodríguez', 101, 'MARTESxJUEVES-1PM-A-2:55PM'), ('MATEMATICA DISCRETA', 'Beatriz Hernández Pérez', 101, 'VIERNES-1PM-A-5PM'), ('CALCULO DIFERENCIAL E INTEGRAL', 'Carlos Rodríguez García', 101, 'MARTESxJUEVES-9AM-A-10:55AM'), ('MECANICA', 'Carolina García Sánchez', 102, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('ADMINISTRACION DE PROYECTOS TECNOLOGICOS', 'Alberto Castro Martínez', 101, 'LUNESxMIERCOLES-1PM-A-2:55PM'), ('EXPRESION ORAL Y ESCRITA', 'Alejandro García Fernández', 103, 'MARTESxJUEVES-9AM-A-10:55AM'), ('PROGRAMACION ORIENTADA A OBJETOS', 'Claudia Sánchez Rodríguez', 102, 'VIERNES-1PM-A-5PM'), ('ALGEBRA LINEAL', 'Carlos Rodríguez García', 101, 'MARTESxJUEVES-3PM-A-4:55PM'), ('ECUACIONES DIFERENCIALES', 'Carlos Rodríguez García', 102, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('CIRCUITOS ELECTRICOS Y ELECTROMAGNETISMO', 'Eduardo Pérez Sánchez', 102, 'LUNESxMIERCOLES-3PM-A-4:55PM'), ('SISTEMAS DIGITALES', 'Eduardo Pérez Sánchez', 103, 'VIERNES-1PM-A-5PM'), ('ADMINISTRACION', 'Alejandro García Fernández', 102, 'MARTESxJUEVES-11AM-A-12:55PM'), ('ESTRUCTURA DE DATOS', 'Elena Ramírez González', 103, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('METODOS NUMERICOS', 'Carolina García Sánchez', 101, 'VIERNES-9AM-A-1PM'), ('ARQUITECTURA DE COMPUTADORAS', 'Eduardo Pérez Sánchez', 105, 'MARTESxJUEVES-9AM-A-10:55AM'), ('PROGRAMACION PARA INTERNET', 'Elena Ramírez González', 102, 'LUNESxMIERCOLES-1PM-A-2:55PM'), ('LIDERAZGO Y EMPRENDIMIENTO', 'Alejandro García Fernández', 103, 'MARTESxJUEVES-1PM-A-2:55PM'), ('ANALISIS DE ALGORITMOS', 'Elena Ramírez González', 104, 'VIERNES-1PM-A-5PM'), ('BASES DE DATOS', 'Isabel Pérez Martínez', 102, 'VIERNES-9AM-A-1PM'), ('SISTEMA OPERATIVOS', 'Isabel Pérez Martínez', 103, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('FUNDAMENTOS DE INTELIGENCIA ARTIFICIAL', 'Javier Sánchez Rodríguez', 102, 'MARTESxJUEVES-1PM-A-2:55PM'), ('REDES DE COMPUTADORAS', 'Isabel Pérez Martínez', 103, 'MARTESxJUEVES-3PM-A-4:55PM'), ('SEMINARIO DE INTEGRACION DE PROTOCOLO', 'Ana Rodríguez García', 104, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('INNOVACION TECNOLOGICA', 'Ana Rodríguez García', 103, 'VIERNES-9AM-A-1PM'), ('INTERACCION HUMANO COMPUTADORA', 'Javier Sánchez Rodríguez', 105, 'MARTESxJUEVES-3PM-A-4:55PM'), ('INGENIERIA DE SOFTWARE', 'Juan Martínez López', 105, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('PROGRAMACION DE BAJO NIVEL', 'Javier Sánchez Rodríguez', 105, 'VIERNES-9AM-A-1PM'), ('TEORIA DE LA COMPUTACION', 'Luis González Ramírez', 102, 'MARTESxJUEVES-9AM-A-10:55AM'), ('SEMINARIO DE INTEGRACION DE DESARROLLO', 'Laura Martínez López', 103, 'LUNESxMIERCOLES-1PM-A-2:55PM'), ('LABORATORIO ABIERTO: DISEÑO', 'Laura Martínez López', 105, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('COMPILADORES', 'Juan Martínez López', 105, 'MARTESxJUEVES-1PM-A-2:55PM'), ('SEGURIDAD EN LA INFORMACION', 'Juan Martínez López', 105, 'VIERNES-1PM-A-5PM'), ('LABORATORIO ABIERTO: CONSTRUCCION', 'Laura Martínez López', 107, 'VIERNES-1PM-A-5PM'), ('LOGICA Y CONJUNTOS', 'Manuel López Martínez', 106, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('INTRODUCCION A LA FISICA', 'Manuel López Martínez', 106, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('TALLER DE INTRODUCCION A LA COMPUTACION', 'Luis González Ramírez', 103, 'MARTESxJUEVES-11AM-A-12:55PM'), ('TALLER DE COMUNICACION ORAL Y ESCRITA', 'Manuel López Martínez', 109, 'VIERNES-1PM-A-5PM'), ('TALLER DE COMUNICACION ORAL Y ESCRITA', 'Patricia López Fernández', 104, 'MARTESxJUEVES-9AM-A-10:55AM'), ('INTRODUCCION A LA COMPUTACION', 'Luis González Ramírez', 106, 'MARTESxJUEVES-1PM-A-2:55PM'), ('INTRODUCCION A LA COMPUTACION', 'María González Rodríguez', 105, 'LUNESxMIERCOLES-1PM-A-2:55PM'), ('TALLER DE REDACCION', 'Patricia López Fernández', 103, 'LUNESxMIERCOLES-3PM-A-4:55PM'), ('INTRODUCCION A LA PROGRAMACION', 'María González Rodríguez', 104, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('ELEMENTOS DE PROBABILIDAD Y ESTADISTICA', 'Patricia López Fernández', 107, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('TALLER DE PROGRAMACION ORIENTADA A OBJETOS', 'María González Rodríguez', 108, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('AUDITORIA DE SISTEMAS', 'Raúl Hernández Pérez', 106, 'LUNESxMIERCOLES-1PM-A-2:55PM'), ('SISTEMAS DE INFORMACION FINANCIEROS', 'Raúl Hernández Pérez', 108, 'LUNESxMIERCOLES-9AM-A-10:55AM'), ('SISTEMAS DE INFORMACION PARA LA MANOFACTURA', 'Raúl Hernández Pérez', 109, 'LUNESxMIERCOLES-11AM-A-12:55PM'), ('TALLER DE ESTRUCTURA DE DATOS', 'Sergio Ramírez González', 105, 'LUNESxMIERCOLES-3PM-A-4:55PM'), ('ADMINISTRACION DE RECURSOS HUMANOS', 'Sergio Ramírez González', 106, 'MARTESxJUEVES-3PM-A-4:55PM'), ('PROGRAMACION Y LOGICA FUNCIONAL', 'Sergio Ramírez González', 106, 'VIERNES-1PM-A-5PM'), ('LEGISLACION EN INFORMATICA', 'Silvia Castro Martínez', 106, 'VIERNES-9AM-A-1PM'), ('TALLER DE PROGRAMACION DE SISTEMAS', 'Silvia Castro Martínez', 107, 'MARTESxJUEVES-9AM-A-10:55AM'), ('SISTEMAS DE INFORMACION ADMINISTRATIVOS', 'Silvia Castro Martínez', 108, 'VIERNES-1PM-A-5PM'), ('INVESTIGACION DE OPERACIONES', 'Carolina García Sánchez', 108, 'LUNESxMIERCOLES-1PM-A-2:55PM')]

    crear_tabla(mi_matriz)
    
    