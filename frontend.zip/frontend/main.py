from forms.form_master import MasterPanel

MasterPanel()